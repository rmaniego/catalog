""" maguro """
__version__ = "1.0.1"
from .maguro import Maguro
__all__ = ["maguro"]