""" maguro """
version = "0.0.9"