# Maguro
Maguro is a lightweight python package that simplifies the management of C/TSV data and files.
