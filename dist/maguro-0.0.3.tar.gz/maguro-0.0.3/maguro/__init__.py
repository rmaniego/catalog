""" maguro """
from .version import version as __version__
from .maguro import Maguro
__all__ = ["maguro"]