""" maguro """
__version__ = "1.0.2"
from .maguro import Maguro
__all__ = ["maguro"]