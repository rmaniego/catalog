""" maguro """
__version__ = "1.0.0"
from .maguro import Maguro
__all__ = ["maguro"]