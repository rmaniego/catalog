""" maguro """
__version__ = "1.1.2"
from .maguro import Maguro
__all__ = ["maguro"]